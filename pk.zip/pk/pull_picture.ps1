﻿#param ( 
#   [Parameter(mandatory=$true)] [string]$mydir,
##   [Parameter(mandatory=$true)] [string]$myuser
#)

function do-Move {
[CmdletBinding()]
param(
    [Parameter(mandatory=$true)] [string]$myfile,
    [Parameter(mandatory=$true)] [string]$mydir
    )
    $shortfile = [System.IO.Path]::GetFileName($myfile)
    $tgtfile = $mydir + "\" + $shortfile ;
    $exist1 = Test-Path $tgtfile
    if ( $exist1 -eq $true ) { 
        $nop=1; 
        $msg="File Move Skipped " + $tgtfile; 
        Write-host -ForegroundColor DarkYellow $msg;   
        Remove-Item $myfile
        }
    else { Move-Item $myfile $mydir; }
}

function do-Copy {
[CmdletBinding()]
param(
    [Parameter(mandatory=$true)] [string]$myfile,
    [Parameter(mandatory=$true)] [string]$mydir,
    [Parameter(mandatory=$true)] [string]$mydir2
    )
    $basename = [io.path]::GetFileNameWithoutExtension( $myfile )
    $basename2 = $basename + ".jpg"
    $tgtfile = $mydir + "\" + $basename2 ;
    $tgtfile2 = $mydir2 + "\" + $basename2 ;
    $exist1 = Test-Path $tgtfile
    $exist2 = Test-Path $tgtfile2
    if ( $exist1 -eq $true -or $exist2 -eq $true ) {
       if ($exist1) { $msg="File Present Skipped  " + $tgtfile;     Write-host -ForegroundColor DarkGreen $msg;  }
       if ($exist2) { $msg="File Present Skipped2 " + $tgtfile2;    Write-host -ForegroundColor DarkGreen $msg;  }
    }
    else { 
       Copy-Item $myfile $mydir; 
       $msg="Copied file " + $myfile;
       Write-host -ForegroundColor DarkGreen $msg;   
       $msg="         to " + $mydir;
       Write-host -ForegroundColor DarkBlue $msg;   
       sleep(1);
    }
}


function Get-CurrentUserSID {            
[CmdletBinding()]            
param()            
            
Add-Type -AssemblyName System.DirectoryServices.AccountManagement            
return ([System.DirectoryServices.AccountManagement.UserPrincipal]::Current).SID.Value            

}

$mysid = Get-CurrentUserSID
Write-Output $mysid
$mydir = "c:\pk\arch1"
$mydir2 = "c:\pk\arch2"

$rkey = "hklm:HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\Creative\" + $mysid 

$data1 = Get-ChildItem $rkey
$nop=1

$flag1 = [bool]($data1.PSobject.Properties.name -match "^Count")


if ( $flag1 -eq $true ) {
    $msg3 = "We have " + $data1.Count.ToString() + " Files"
    Write-Warning $msg3 
    for ($x=0; $x -lt $data1.Count; $x++ ) {
       $data2 = $data1.Get($x)
       $JPG_File = $data2.GetValue("landscapeImage")
       do-Copy $JPG_File $mydir $mydir2
    }

} else {
    $data2 = $data1
    $JPG_File = $data2.GetValue("landscapeImage")
    do-Copy $JPG_File $mydir $mydir2

}

cd $mydir

$a = Get-ChildItem .
 
[int] $x=0;
for ($x=0; $x -lt $a.count; $x++) {
    [String] $attrib = $a[$x].mode
    if ( $attrib.startswith("-") ) {
           $fileName1 = $a[$x].FullName ;
           $oldday = (Get-Date).AddDays(0) - $a[$x].LastWriteTime
           $FileExt1 = $fileName1.Substring($fileName1.Length - 3,3)

           Switch ( $FileExt1 ) {
             "jpg" {
                      if ( $oldday.Days -ge 2 ) {
                         do-Move $fileName1 $mydir2
                         Start-Sleep -Seconds 1
                      }  
                      break; 
                   }
             "txt" {  break; }
             "ps1" {  break; }
             "bat" {  break; }
             "dat" {  break; }
             "out" {  break; }
             default {
               $newn = $fileName1 + ".jpg"
               $exist1 = Test-Path $newn
               if ( $exist1 -eq $true ) { 
                   $nop=1;
                   #emove-Item $fileName1; 
               }
               else { Move-Item $fileName1 $newn;
                      $msg3 = "Moved file: " + $newn ;
                      Write-Output $msg3;
                      Start-Sleep -Seconds 1; 
                    }
             }
           }
    }
    
}

Start-Sleep -Seconds 10
## $nop = read-host 'Press Enter'