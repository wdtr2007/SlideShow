2021-03-18

Pull Picture
by
James S.
wdtr2002@yahoo.com

The following is copyrighted by me.
This can be distributed to anyone for free.

The software is "as is", use at your own caution.
We are not responsible for any issues that this may cause.

the only think I can say is I designed this, and it worked 
well on Windows 10 in 2021.

Installation:
=============
1) make a directory called c:\pk
2) unzip all the files into that directory
3) Make a shortcut on your desktop for pull_picture.bat
4) Make a shortcut on your desktop for 
